namespace Dio.series

{

    public abstract class EntidadeBase
    {
        public int Id { get; protected set; }
    }
    
}